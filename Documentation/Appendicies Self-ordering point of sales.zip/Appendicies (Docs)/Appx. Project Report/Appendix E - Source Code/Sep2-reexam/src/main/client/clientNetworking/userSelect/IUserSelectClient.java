package main.client.clientNetworking.userSelect;

public interface IUserSelectClient {
    boolean testConnection();
}
