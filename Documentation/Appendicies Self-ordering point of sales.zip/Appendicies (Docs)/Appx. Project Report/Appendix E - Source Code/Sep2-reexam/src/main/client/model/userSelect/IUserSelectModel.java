package main.client.model.userSelect;

public interface IUserSelectModel {
    boolean testConnection();
}
