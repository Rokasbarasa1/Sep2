package main.client.clientNetworking.customerMenu;

import main.shared.Item;

import java.util.ArrayList;

public interface ICustomerMenuClient {
    ArrayList<Item> getMenu();
}
