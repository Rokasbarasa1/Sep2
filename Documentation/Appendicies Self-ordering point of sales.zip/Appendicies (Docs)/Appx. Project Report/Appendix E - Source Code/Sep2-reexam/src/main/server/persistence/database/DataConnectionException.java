package main.server.persistence.database;

public class DataConnectionException extends Exception {
    public DataConnectionException(String message) {super(message);}
}
