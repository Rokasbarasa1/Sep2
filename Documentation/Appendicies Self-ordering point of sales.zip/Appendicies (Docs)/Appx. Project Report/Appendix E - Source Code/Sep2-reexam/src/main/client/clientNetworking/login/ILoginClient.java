package main.client.clientNetworking.login;

import main.shared.Receptionist;

public interface ILoginClient {
    String Login(Receptionist loginCarrier);
}
